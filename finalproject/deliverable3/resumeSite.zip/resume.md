<img src="avatar.jpg" alt="Apache logo" style="height:15vh;width:15vw;"><br>

# Andeivi Mejia Taveras


## Jr Web Developer
---
Motivated and detail-oriented web development student with experience in Java, Python, and C++. Actively learning HTML and CSS, with upcoming classes in Javascript. Enthusiastic about adapting to innovative technologies and environments to create functional projects. Strong critical thinking skills and ability to contribute to both independent and team settings. Exceptional customer service skills gained from retail experience. Fluent in Spanish.
<br>
<br>

---
## Experience
---
### The Home Depot
#### Retail Cashier • May, 2021 - Present
As a cashier at The Home Depot, I engage with customers, help with purchases, and assist in enrolling them in rewards programs. I handle transactions accurately, answer questions about store policies, and address concerns promptly. My friendly service promotes customer loyalty and satisfaction. I also maintain organized merchandise in the front lanes to enhance the shopping experience.
<br>
<br>

---
## Education
---
### Passaic County Community College
#### Web and Mobile Development • 2021 - 2024 Expected

<br>
<br>

### Passaic High School
#### High School Diploma • 2017 - 2021
<br>

---
## Skills
---
- HTML & CSS
- Python, Java, & C++
- Critical Thinking
- Social Perceptiveness
- Computer Assembly and Maintenance
- Virtualization